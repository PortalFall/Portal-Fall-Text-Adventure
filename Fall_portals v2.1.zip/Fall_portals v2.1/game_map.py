import os
import random




#### Maps for the player locations ####
def Print_map():
    if myPlayer.location == 'Street':
        Random_encounter()
        # winsound.PlaySound("C:\outsidewalk.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │░   X    ░│
            └───├   ┼───┘
                │   │
                ├   ┤
                │   │
                ├   ┤
                │   │
                ├   ┼───┐
                │     ░│
                └───┴───┘   




        """)
    elif myPlayer.location == 'Street2':
        Random_encounter()
        # winsound.PlaySound("C:\outsidewalk.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │░        ░│
            └───├   ┼───┘
                │ X │
                ├   ┤
                │   │
                ├   ┤
                │   │
                ├   ┼───┐
                │     ░│
                └───┴───┘  




        """)

    elif myPlayer.location == 'Street3':
        Random_encounter()
        # winsound.PlaySound("C:\outsidewalk.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │░        ░│
            └───├   ┼───┘
                │   │
                ├   ┤
                │   │
                ├   ┤
                │ X │
                ├   ┼───┐
                │     ░│
                └───┴───┘   




        """)
    elif myPlayer.location == 'Street4':
        Random_encounter()
        # winsound.PlaySound("C:\outsidewalk.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │░        ░│
            └───├   ┼───┘
                │   │
                ├   ┤
                │   │
                ├   ┤
                │   │
                ├   ┼───┐
                │ X   ░│
                └───┴───┘   
            



        """)

    elif myPlayer.location == 'Library Lobby':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""

                +---+---+---+
                | EX| X |   |
                +---+---+---+
                    |   |   |
                    +---+---+


        """)

    elif myPlayer.location == 'Library Conference':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""

                +---+---+---+
                | EX|   | X |
                +---+---+---+
                    |   |   |
                    +---+---+


        """)
    elif myPlayer.location == 'Library Cafe':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""

                +---+---+---+
                | EX|   |   |
                +---+---+---+
                    | X |   |
                    +---+---+


        """)
    elif myPlayer.location == 'Library Research':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""

                +---+---+---+
                | EX|   |   |
                +---+---+---+
                    |   | X |
                    +---+---+


        """)


    elif myPlayer.location == 'Shop':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""

                ┌───┬───┐
                │ ░  X │
                └───┴───┘
            


                """)
    elif myPlayer.location == 'BedRoom':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │         ░│
            └───├   ┼───┘
                │   │
            ┌───┼   ┤
            │ X     │
            └───┼   ┤
                │   │
                └───┘

            """)


    elif myPlayer.location == 'Foyer':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │     X   ░│
            └───├   ┼───┘
                │   │
            ┌───┼   ┤
            │       │
            └───┼   ┤
                │   │
                └───┘

            """)

    elif myPlayer.location == 'Kitchen':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │         ░│
            └───├   ┼───┘
                │ X │
            ┌───┼   ┤
            │       │
            └───┼   ┤
                │   │
                └───┘

                    """)

    elif myPlayer.location == 'Study':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')

        print("""
            ┌───┬───┬───┐
            │         ░│
            └───├   ┼───┘
                │   │
            ┌───┼   ┤
            │     X │
            └───┼   ┤
                │   │
                └───┘

                    """)

    elif myPlayer.location == 'Basement':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │         ░│
            └───├   ┼───┘
                │   │
            ┌───┼   ┤
            │       │
            └───┼   ┤
                │ X │
                └───┘

                            """)

    elif myPlayer.location == 'LivingRoom':
        # winsound.PlaySound("C:\SD2.wav", winsound.SND_ASYNC)
        os.system('cls')
        print("""
            ┌───┬───┬───┐
            │ X       ░│
            └───├   ┼───┘
                │   │
            ┌───┼   ┤
            │       │
            └───┼   ┤
                │   │
                └───┘

            """)